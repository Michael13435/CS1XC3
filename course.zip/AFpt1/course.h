/**
 * @file course.h
 * @author Michael Shadoff (Just the comments, code was provided)
 * @brief This file defines the course data structure and initializes some functions that course.c will define
 * @version 0.1
 * @date 2022-04-05
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "student.h"
#include <stdbool.h>
 

/**
 * @brief This is the definition for the course data structure. This contains the course name, course code, students in
 * the course, and the total number of students in the course
 * 
 * The students in the course are of type "student" which is classified in the student.h file
 * 
 */
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


