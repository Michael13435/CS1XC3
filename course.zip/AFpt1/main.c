/**
 * @file main.c
 * @author Michael Shadoff (Just the comments, code was provided)
 * @brief This file uses the functions for the course and student data structures to construct a course with students taking it
 * @version 0.1
 * @date 2022-04-05
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief This function creates the course math101 using the course data structure established earlier. Then it generates 20 random students and adds them to the class
 * using the enroll_student and generate_random_student functions. Then it uses the passing function to create a list of the students that are passing. The variable
 * total passing also tracks the number of students passing. Finally it prints the number of students passing and the names of the students passing. Also note that all
 * the random number generation uses time as the seed.
 * 
 * 
 * 
 * @return int (This value doesn't seem to have a purpose)
 */

int main()
{
  srand((unsigned) time(NULL));

  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}